package com.jojandev.api.services;

import com.jojandev.api.dao.PersonalDAO;
import com.jojandev.api.models.Personal;
import com.jojandev.api.providers.ResponseProvider;
import java.util.ArrayList;
import java.util.List;

public class PersonalService {
    
    public static ResponseProvider getPersonales(){
        try {
            final PersonalDAO objDao = new PersonalDAO();
        
            final List<Personal> personales = objDao.getAll();

            if (personales.isEmpty())
                return new ResponseProvider(true, 404, "No hay personal registrado", null, null);
            

            return new ResponseProvider(true, 200, "Personal obtenido correctamente", personales, null); 
        } catch (Exception e) {
            return new ResponseProvider(true, 500, "Error al obtener el personal", null, null); 
        }
    }
}
    