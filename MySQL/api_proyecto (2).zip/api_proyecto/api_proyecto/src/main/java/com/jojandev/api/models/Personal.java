package com.jojandev.api.models;

public class Personal {
    private int id;
    private int id_info;
    private String contrasena;
//    private String roles; 
    private String usuario;
    
    public Personal() {}

    public Personal(int id, int id_info, String contrasena, String usuario) {
        this.id = id;
        this.id_info = id_info;
        this.contrasena = contrasena;
//        this.roles = roles;
        this.usuario = usuario;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_info() {
        return id_info;
    }

    public void setId_info(int id_info) {
        this.id_info = id_info;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

//    public String getRoles() {
//        return roles;
//    }
//
//    public void setRoles(String roles) {
//        this.roles = roles;
//    }
    
    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
}
