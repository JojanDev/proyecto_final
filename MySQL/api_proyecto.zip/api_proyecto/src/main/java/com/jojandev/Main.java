package com.jojandev;

import com.jojandev.api.models.Personal;
import com.jojandev.api.utils.ConexionBD;
import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

import java.net.URI;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static final String BASE_URI = "http://localhost:8080/api/";

    public static HttpServer startServer() {
        final ResourceConfig rc = new ResourceConfig()
        .packages("com.jojandev", "com.jojandev")
        .register(org.glassfish.jersey.jsonb.JsonBindingFeature.class);

        return GrizzlyHttpServerFactory.createHttpServer(URI.create(BASE_URI), rc);
    }

    public static void main(String[] args) {
        final HttpServer server = startServer();
        System.out.println("Servidor iniciado en " + BASE_URI);
        
//        Connection con = ConexionBD.conectar();
        
        List<Personal> personal = new ArrayList<>();
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM personal");
             ResultSet rs = ps.executeQuery()) {
            
//            System.out.println("============================================");
//            System.out.println("-> Conexión establecida correctamente.");
//            System.out.println("============================================");


            while (rs.next()) {
                Personal p = new Personal();
                p.setId(rs.getInt("id"));
                p.setId_info(rs.getInt("id_info"));
                p.setContrasena(rs.getString("contrasena"));
                p.setUsuario(rs.getString("usuario"));
                personal.add(p);

                // Mostrar en consola los datos de este registro
                System.out.println("ID: " + p.getId());
                System.out.println("ID Info: " + p.getId_info());
                System.out.println("Usuario: " + p.getUsuario());
                System.out.println("Contraseña: " + p.getContrasena());
                System.out.println("-----------------------------");
            }
        } catch (SQLException e) {
            System.out.println("-> Error al conectar a la base de datos: " + e.getMessage());
        }
    }   
}
