/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jojandev.api.dao;

import com.jojandev.api.models.Personal;
import com.jojandev.api.utils.ConexionBD;

import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.core.Response;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Propietario
 */
public class CrudDAO {
    
    public List<Personal> getAll(String tabla){
        List<Personal> personal = new ArrayList<>();
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM " + tabla);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Personal p = new Personal();
                p.setId(rs.getInt("id"));
                p.setId_info(rs.getInt("id_info"));
                p.setContrasena(rs.getString("contrasena"));
//                p.setRoles(rs.getString("roles"));
                p.setUsuario(rs.getString("usuario"));
                personal.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return personal;
    }
    
    
    public void create(String tabla, Object objeto) throws IllegalAccessException {
//        String sql = MessageFormat.format("INSERT INTO {0} (id_info, usuario, contrasena) VALUES (?, ?, ?)", tabla);
        
        StringBuilder columnas = new StringBuilder();
        StringBuilder valores = new StringBuilder();
        List<Object> parametros = new ArrayList<>();

        Field[] campos = objeto.getClass().getDeclaredFields();

        for (Field campo : campos) {
            campo.setAccessible(true);
            if (campo.getName().equalsIgnoreCase("id")) continue; // saltar ID si es autoincremental
            Object valor = campo.get(objeto);

            if (valor != null) {
                columnas.append(campo.getName()).append(", ");
                valores.append("?, ");
                parametros.add(valor);
            }
        }

        columnas.setLength(columnas.length() - 2);
        valores.setLength(valores.length() - 2);

        String sql = MessageFormat.format("INSERT INTO {0} ({1}) VALUES ({2});",
                                    tabla,
                                    columnas,
                                    valores);
        
        try (Connection con = ConexionBD.conectar();
            PreparedStatement ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            for (int i = 0; i < parametros.size(); i++) {
                ps.setObject(i + 1, parametros.get(i));
            }

//            ps.setString(4, personal.getRoles());
            int filasAfectadas = ps.executeUpdate();
            
            if(filasAfectadas > 0){
                ResultSet keys = ps.getGeneratedKeys();
                if(keys.next()){
//                    objeto.setId(keys.getInt(1));
                }
                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public Response actualizarPersona(int id, Personal personal) {
        try {
            Personal existing = buscarPersonaPorId(id);
            if (existing == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
            existing.setId_info(personal.getId_info());
            existing.setContrasena(personal.getContrasena());
//            existing.setRoles(personal.getRoles());
            existing.setUsuario(personal.getUsuario());

            if (actualizarEnBD(existing)) {
                return Response.ok(existing).build();
            } else {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
            }
        } catch (SQLException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
            // .build() finaliza la construcción de la respuesta y la convierte en un objeto Response
        }
    }

    public Response actualizarPersonaParcial(@PathParam("id") int id, Personal persona) {
        try {
            Personal existing = buscarPersonaPorId(id);
            if (existing == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
            if (persona.getContrasena() != null) {
                existing.setContrasena(persona.getContrasena());
            }
            if (persona.getId_info()!= 0) {
                existing.setId_info(persona.getId_info());
            }
            
            if (persona.getUsuario() != null) {
                existing.setUsuario(persona.getUsuario());
            }

            if (actualizarEnBD(existing)) {
                return Response.ok(existing).build();
            } else {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
            }
        } catch (SQLException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    public Response eliminarPersona(@PathParam("id") int id) {
        try {
            Personal existing = buscarPersonaPorId(id);
            if (existing == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
            if (eliminarDeBD(id)) {
                return Response.noContent().build();
            } else {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
            }
        } catch (SQLException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    private Personal buscarPersonaPorId(int id) throws SQLException {
        Personal persona = null;
        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement("SELECT id, id_info, usuario, contrasena FROM personal WHERE id = ?")) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    persona = new Personal();
                    persona.setId(rs.getInt("id"));
                    persona.setContrasena(rs.getString("contrasena"));
                    persona.setId_info(rs.getInt("id_info"));
//                    persona.setRoles(rs.getString("roles"));       
                    persona.setUsuario(rs.getString("usuario"));
                }
            }
        }
        return persona;
    }

    private boolean actualizarEnBD(Personal personal) throws SQLException {
        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement("UPDATE personal SET id_info = ?, usuario = ?, contrasena = ? WHERE id = ?")) {
            stmt.setInt(1, personal.getId_info());
            stmt.setString(2, personal.getUsuario());
            stmt.setString(3, personal.getContrasena());
//            stmt.setString(4, personal.getRoles());
            stmt.setInt(5, personal.getId());
            return stmt.executeUpdate() > 0;
        }
    }

    private boolean eliminarDeBD(int id) throws SQLException {
        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM personal WHERE id = ?")) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
    }
}
