package com.jojandev.api.controller; // Paquete donde está este controlador

// Importación de la clase modelo que representa los tipos de documento
import com.jojandev.api.models.TipoDocumento;

// Importación de clase para conectarse a la base de datos
import com.jojandev.api.utils.ConexionBD;

// Anotaciones de Jakarta para trabajar con API REST
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;

// Librerías de Java para SQL y listas
import java.sql.*;
import java.util.*;

// Ruta base del endpoint: http://localhost:puerto/api/tipos-documento
@Path("/tipos-documento")
public class TipoDocumentoController {

    // Método que maneja las peticiones GET
    @GET
    @Produces(MediaType.APPLICATION_JSON) // Devuelve los datos en formato JSON
    public List<TipoDocumento> obtenerTiposDocumento() {
        List<TipoDocumento> lista = new ArrayList<>(); // Lista que se va a devolver

        try (
            Connection con = ConexionBD.conectar(); // Se abre conexión a la BD
            PreparedStatement ps = con.prepareStatement("SELECT * FROM tipos_documento"); // Consulta SQL
            ResultSet rs = ps.executeQuery() // Se ejecuta la consulta y se obtienen los resultados
        ) {
            // Mientras haya resultados, se recorre cada fila
            while (rs.next()) {
                TipoDocumento td = new TipoDocumento(); // Se crea un nuevo objeto
                td.setId(rs.getInt("id"));              // Se asigna el ID desde la BD
                td.setNombre(rs.getString("nombre"));   // Se asigna el nombre desde la BD
                lista.add(td);                          // Se agrega a la lista
            }

        } catch (Exception e) {
            e.printStackTrace(); // Si hay error, se imprime
        }

        return lista; // Se devuelve la lista como respuesta
    }
}
