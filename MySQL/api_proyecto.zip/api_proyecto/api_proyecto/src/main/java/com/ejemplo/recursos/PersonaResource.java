package com.ejemplo.recursos;

import com.ejemplo.modelo.Persona;
import com.ejemplo.ConexionBD;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

@Path("personas")
public class PersonaResource {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Persona> obtenerPersonas() {
        List<Persona> personas = new ArrayList<>();
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM personas");
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Persona p = new Persona();
                p.setId(rs.getInt("id"));
                p.setNombre(rs.getString("nombre"));
                p.setEdad(rs.getInt("edad"));
                personas.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return personas;
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public void agregarPersona(Persona persona) {
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement("INSERT INTO personas (nombre, edad) VALUES (?, ?)")) {
            ps.setString(1, persona.getNombre());
            ps.setInt(2, persona.getEdad());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
     @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response actualizarPersona(@PathParam("id") int id, Persona persona) {
        try {
            Persona existing = buscarPersonaPorId(id);
            if (existing == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
            existing.setNombre(persona.getNombre());
            existing.setEdad(persona.getEdad());
            if (actualizarEnBD(existing)) {
                return Response.ok(existing).build();
            } else {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
            }
        } catch (SQLException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PATCH
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response actualizarPersonaParcial(@PathParam("id") int id, Persona persona) {
        try {
            Persona existing = buscarPersonaPorId(id);
            if (existing == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
            if (persona.getNombre() != null) {
                existing.setNombre(persona.getNombre());
            }
            if (persona.getEdad() != 0) {
                existing.setEdad(persona.getEdad());
            }
            if (actualizarEnBD(existing)) {
                return Response.ok(existing).build();
            } else {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
            }
        } catch (SQLException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DELETE
    @Path("/{id}")
    public Response eliminarPersona(@PathParam("id") int id) {
        try {
            Persona existing = buscarPersonaPorId(id);
            if (existing == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
            if (eliminarDeBD(id)) {
                return Response.noContent().build();
            } else {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
            }
        } catch (SQLException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    private Persona buscarPersonaPorId(int id) throws SQLException {
        Persona persona = null;
        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement("SELECT id, nombre, edad FROM personas WHERE id = ?")) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    persona = new Persona();
                    persona.setId(rs.getInt("id"));
                    persona.setNombre(rs.getString("nombre"));
                    persona.setEdad(rs.getInt("edad"));
                }
            }
        }
        return persona;
    }

    private boolean actualizarEnBD(Persona persona) throws SQLException {
        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement("UPDATE personas SET nombre = ?, edad = ? WHERE id = ?")) {
            stmt.setString(1, persona.getNombre());
            stmt.setInt(2, persona.getEdad());
            stmt.setInt(3, persona.getId());
            return stmt.executeUpdate() > 0;
        }
    }

    private boolean eliminarDeBD(int id) throws SQLException {
        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM personas WHERE id = ?")) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
    }

}

