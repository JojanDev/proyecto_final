package com.jojandev.api.routes;

import com.jojandev.api.models.Personal;
import com.jojandev.api.utils.ConexionBD;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response; //No se usaria
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

//@Path("personal")
public class PersonalRoutes {

//    @GET
//    @Produces(MediaType.APPLICATION_JSON)
//    public void get() {
//        
//    }
    
//    @GET
//    @Produces(MediaType.APPLICATION_JSON)
//    public List<Personal> obtenerPersonas() {
//        List<Personal> personas = new ArrayList<>();
//        try (Connection con = ConexionBD.conectar();
//             PreparedStatement ps = con.prepareStatement("SELECT * FROM personal");
//             ResultSet rs = ps.executeQuery()) {
//
//            while (rs.next()) {
//                Personal p = new Personal();
//                p.setId(rs.getInt("id"));
//                p.setId_info(rs.getInt("id_info"));
//                p.setContrasena(rs.getString("contrasena"));
//                p.setRoles(rs.getString("roles"));
//                p.setUsuario(rs.getString("usuario"));
//                personas.add(p);
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return personas;
//    }
//
//    @POST
//    @Consumes(MediaType.APPLICATION_JSON)
//    public void agregarPersona(Personal personal) {
//        try (Connection con = ConexionBD.conectar();
//            PreparedStatement ps = con.prepareStatement("INSERT INTO personal (id_info, usuario, contrasena, roles) VALUES (?, ?, ?, ?)")) {
//            ps.setInt(1, personal.getId_info());
//            ps.setString(2, personal.getUsuario());
//            ps.setString(3, personal.getContrasena());
//            ps.setString(4, personal.getRoles());
//            ps.executeUpdate();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//    
//     @PUT
//    @Path("/{id}")
//    @Consumes(MediaType.APPLICATION_JSON)
//    public Response actualizarPersona(@PathParam("id") int id, Personal personal) {
//        try {
//            Personal existing = buscarPersonaPorId(id);
//            if (existing == null) {
//                return Response.status(Response.Status.NOT_FOUND).build();
//            }
//            existing.setId_info(personal.getId_info());
//            existing.setContrasena(personal.getContrasena());
//            existing.setRoles(personal.getRoles());
//            existing.setUsuario(personal.getUsuario());
//
//            if (actualizarEnBD(existing)) {
//                return Response.ok(existing).build();
//            } else {
//                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//            }
//        } catch (SQLException e) {
//            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//        }
//    }
//
//    @PATCH
//    @Path("/{id}")
//    @Consumes(MediaType.APPLICATION_JSON)
//    public Response actualizarPersonaParcial(@PathParam("id") int id, Personal persona) {
//        try {
//            Personal existing = buscarPersonaPorId(id);
//            if (existing == null) {
//                return Response.status(Response.Status.NOT_FOUND).build();
//            }
//            if (persona.getContrasena() != null) {
//                existing.setContrasena(persona.getContrasena());
//            }
//            if (persona.getId_info()!= 0) {
//                existing.setId_info(persona.getId_info());
//            }
//            if (persona.getRoles()!= null) {
//                existing.setRoles(persona.getRoles());
//            }
//            
//            if (persona.getUsuario() != null) {
//                existing.setUsuario(persona.getUsuario());
//            }
//
//            if (actualizarEnBD(existing)) {
//                return Response.ok(existing).build();
//            } else {
//                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//            }
//        } catch (SQLException e) {
//            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//        }
//    }
//
//    @DELETE
//    @Path("/{id}")
//    public Response eliminarPersona(@PathParam("id") int id) {
//        try {
//            Personal existing = buscarPersonaPorId(id);
//            if (existing == null) {
//                return Response.status(Response.Status.NOT_FOUND).build();
//            }
//            if (eliminarDeBD(id)) {
//                return Response.noContent().build();
//            } else {
//                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//            }
//        } catch (SQLException e) {
//            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//        }
//    }
//
//    private Personal buscarPersonaPorId(int id) throws SQLException {
//        Personal persona = null;
//        try (Connection conn = ConexionBD.conectar();
//             PreparedStatement stmt = conn.prepareStatement("SELECT id, id_info, usuario, contrasena, roles FROM personal WHERE id = ?")) {
//            stmt.setInt(1, id);
//            try (ResultSet rs = stmt.executeQuery()) {
//                if (rs.next()) {
//                    persona = new Personal();
//                    persona.setId(rs.getInt("id"));
//                    persona.setContrasena(rs.getString("contrasena"));
//                    persona.setId_info(rs.getInt("id_info"));
//                    persona.setRoles(rs.getString("roles"));       
//                    persona.setUsuario(rs.getString("usuario"));
//                }
//            }
//        }
//        return persona;
//    }
//
//    private boolean actualizarEnBD(Personal personal) throws SQLException {
//        try (Connection conn = ConexionBD.conectar();
//             PreparedStatement stmt = conn.prepareStatement("UPDATE personal SET id_info = ?, usuario = ?, contrasena = ?, roles = ? WHERE id = ?")) {
//            stmt.setInt(1, personal.getId_info());
//            stmt.setString(2, personal.getUsuario());
//            stmt.setString(3, personal.getContrasena());
//            stmt.setString(4, personal.getRoles());
//            stmt.setInt(5, personal.getId());
//            return stmt.executeUpdate() > 0;
//        }
//    }
//
//    private boolean eliminarDeBD(int id) throws SQLException {
//        try (Connection conn = ConexionBD.conectar();
//             PreparedStatement stmt = conn.prepareStatement("DELETE FROM personal WHERE id = ?")) {
//            stmt.setInt(1, id);
//            return stmt.executeUpdate() > 0;
//        }
//    }

}

