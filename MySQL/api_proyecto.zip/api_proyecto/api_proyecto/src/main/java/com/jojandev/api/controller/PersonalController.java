package com.jojandev.api.controller;

import jakarta.ws.rs.core.Response;

public class PersonalController {
    
    public static void getAllPersonal(){
        
    }
    
//    public Response getAllPersonas() {
//        List<Persona> personas = PersonaDAO.obtenerTodas();
//        return Response.ok(personas).build();
//    }
//
//    public Response agregarPersona(Persona persona) {
//        if (persona.getNombre() == null || persona.getEdad() < 0) {
//            return Response.status(400).entity("Datos inválidos").build();
//        }
//
//        PersonaDAO.insertar(persona);
//        return Response.status(201).entity("Persona agregada").build();
//    }
}
