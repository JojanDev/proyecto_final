
package com.jojandev.api.controller;

import com.jojandev.api.models.InformacionClientesPersonal;
import com.jojandev.api.utils.ConexionBD;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.json.Json;
import jakarta.json.JsonObject;
import java.sql.Statement;

@Path("/informacion-clientes-personal")
public class InformacionClientesPersonalController {

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response agregarInformacion(InformacionClientesPersonal info) {
        try (Connection con = ConexionBD.conectar()) {
            String sql = "INSERT INTO informacion_clientes_personal (id_tipo_documento, numero_documento, nombre, telefono, correo, direccion) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            ps.setInt(1, info.getIdTipoDocumento());
            ps.setString(2, info.getNumeroDocumento());
            ps.setString(3, info.getNombre());
            ps.setString(4, info.getTelefono());
            ps.setString(5, info.getCorreo());
            ps.setString(6, info.getDireccion());

            int filas = ps.executeUpdate();
            if (filas > 0) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    int idGenerado = rs.getInt(1);
                    JsonObject json = Json.createObjectBuilder()
                        .add("success", true)
                        .add("id", idGenerado)
                        .build();
                    return Response.ok(json.toString(), MediaType.APPLICATION_JSON).build();
                }else {
                    System.out.println("No se obtuvo clave generada.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
      
        JsonObject error = Json.createObjectBuilder()
        .add("success", false)
        .add("message", "Error al insertar.")
        .build();
        return Response.serverError().entity(error.toString()).build();
    }
}
